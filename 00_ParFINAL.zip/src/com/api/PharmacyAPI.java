package com.api;

import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.vo.Pharmacy;

public class PharmacyAPI {
	
	public static void main(String[] args) {
		
		List<Pharmacy> list = callPharmacyByXML();
		
		for(Pharmacy p : list) {
			System.out.println(p.toString());
		}
		System.out.println(list.size());
	}

//	상세정보 → https://www.data.go.kr/data/15000576/openapi.do
//	요청url → http://apis.data.go.kr/B552657/ErmctInsttInfoInqireService/getParmacyBassInfoInqire?ServiceKey=EuGsY1gDb%2Fc%2Fb0aj%2FG0pZwpEe1NR7OMMfLz8AtTOWGA2tDQl7ujiuBbdZX0tbpu2w8fPdCSQVpdHPwJS15UAyg%3D%3D&pageNo=1&numOfRows=10		
	public static final String PHARMACY_XML_URL = "http://apis.data.go.kr/B552657/ErmctInsttInfoInqireService/getParmacyBassInfoInqire";
	public static int pageNo = 1;
	public static int numOfRows = 100;
	
	public static List<Pharmacy> callPharmacyByXML() {
		
		List<Pharmacy> list = new ArrayList<Pharmacy>();
		
		while(true) {
			StringBuilder urlBuffer = new StringBuilder(PHARMACY_XML_URL);
			urlBuffer.append("?" + "ServiceKey=" + "EuGsY1gDb%2Fc%2Fb0aj%2FG0pZwpEe1NR7OMMfLz8AtTOWGA2tDQl7ujiuBbdZX0tbpu2w8fPdCSQVpdHPwJS15UAyg%3D%3D");
			urlBuffer.append("&" + "pageNo=" + pageNo);
			urlBuffer.append("&" + "numOfRows=" + numOfRows);
			urlBuffer.append("&" + "type=" + "xml");
//			System.out.println(urlBuffer);
			
			try {
				URL url = new URL(urlBuffer.toString());
				HttpURLConnection conn = (HttpURLConnection) url.openConnection();
				conn.setRequestMethod("GET");
				conn.setRequestProperty("Accept", "application/xml");
				int code = conn.getResponseCode(); // 실제 호출하는부
//				System.out.println("Response code: " + code);
				
				if (code < 200 || code > 300) {
					System.out.println("페이지가 잘못되었습니다.");
				}
				
				// 페이지 Parsing(해석)
				DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
				DocumentBuilder db = dbf.newDocumentBuilder();

				Document doc = db.parse(conn.getInputStream()); // xml 부를 파싱하여 객체화

				doc.getDocumentElement().normalize();

//				System.out.println("Root Element : " + doc.getDocumentElement().getNodeName());
//				System.out.println("======================================================");

				NodeList nList = doc.getElementsByTagName("item");

				if (nList.getLength() <= 0) {
					return list;
				}
				
				for (int i = 0; i < nList.getLength(); i++) {
					Node node = nList.item(i);
//							System.out.println("\nCurrent Element : " + node.getNodeName());
					if (node.getNodeType() == Node.ELEMENT_NODE) {
						try {
							Element pElement = (Element) node;

							String dutyUrl = getStrData(pElement, "dutyUrl");
							String dutyAddr = getStrData(pElement, "dutyAddr");
							String dutyInf = getStrData(pElement, "dutyInf");
							String dutyMapimg = getStrData(pElement, "dutyMapimg");
							String dutyName = getStrData(pElement, "dutyName");
							String dutyTel1 = getStrData(pElement, "dutyTel1");
							String dutyTime1c = getStrData2(pElement, "dutyTime1c");
							String dutyTime6c = getStrData2(pElement, "dutyTime6c");
							String dutyTime7c = getStrData2(pElement, "dutyTime7c");
							String dutyTime8c = getStrData2(pElement, "dutyTime8c");
							String dutyTime1s = getStrData2(pElement, "dutyTime1s");
							String dutyTime6s = getStrData2(pElement, "dutyTime6s");
							String dutyTime7s = getStrData2(pElement, "dutyTime7s");
							String dutyTime8s = getStrData2(pElement, "dutyTime8s");
							String postCdn1 = getStrData(pElement, "postCdn1");
							String postCdn2 = getStrData(pElement, "postCdn2");
							String wgs84Lon = getStrData(pElement, "wgs84Lon");
							String wgs84Lat = getStrData(pElement, "wgs84Lat");
									
							Pharmacy p = new Pharmacy(dutyUrl, dutyAddr, dutyInf, dutyMapimg, dutyName,
									dutyTel1, dutyTime1c, dutyTime6c, dutyTime7c, dutyTime8c, dutyTime1s,
									dutyTime6s, dutyTime7s, dutyTime8s, postCdn1, postCdn2, wgs84Lon, wgs84Lat);
							
							list.add(p);
						} catch (Exception e) {
							System.out.println("데이터가 잘못되었습니다.");
						}
					}
				}
				System.out.println("페이지 : " + pageNo++);
				
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}
	
	private static String getStrData(Element pElement, String tagName) {
		try {
			return pElement.getElementsByTagName(tagName).item(0).getTextContent().trim();
		} catch (Exception e) {
			return "-";
		}
	}
	
	private static String getStrData2(Element pElement, String tagName) {
		try {
			return pElement.getElementsByTagName(tagName).item(0).getTextContent().substring(0, 2) + ":" 
		+ pElement.getElementsByTagName(tagName).item(0).getTextContent().substring(2, 4);
		} catch (Exception e) {
			return "-";
		}
	}
}