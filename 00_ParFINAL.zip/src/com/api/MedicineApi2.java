package com.api;

import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.vo.Medicine2;

public class MedicineApi2 {
	// 낱알검색
	
	public static int pageNo = 1;
	public static List<Medicine2> searchAll() {
		List<Medicine2> list = new ArrayList<>();
		
		while(true) {
		try {
			StringBuilder urlBuilder = new StringBuilder("http://apis.data.go.kr/1471000/MdcinGrnIdntfcInfoService01/getMdcinGrnIdntfcInfoList01"); /*URL*/
	        urlBuilder.append("?" + URLEncoder.encode("serviceKey","UTF-8") + "=qox%2BipaXoWnf%2FV01eNjOkt81Eh8nOc%2Fr82zCfdYqtbzqdsVuZr2o1iAq7VI8I0J8L71uxntJKSdmuP91QTQpEQ%3D%3D"); /*Service Key*/
//	        urlBuilder.append("&" + URLEncoder.encode("item_name","UTF-8") 	+ "=" + URLEncoder.encode("", "UTF-8")); /*품목명*/
//	        urlBuilder.append("&" + URLEncoder.encode("entp_name","UTF-8") 	+ "=" + URLEncoder.encode("", "UTF-8")); /*업체명*/
//	        urlBuilder.append("&" + URLEncoder.encode("item_seq","UTF-8") + "=" + URLEncoder.encode("", "UTF-8")); /*품목일련번호*/
//	        urlBuilder.append("&" + URLEncoder.encode("img_regist_ts","UTF-8") + "=" + URLEncoder.encode("", "UTF-8")); /*약학정보원 이미지 생성일*/
	        urlBuilder.append("&" + "pageNo=" + pageNo); /*페이지번호*/
	        urlBuilder.append("&" + URLEncoder.encode("numOfRows","UTF-8") + "=" + URLEncoder.encode("300", "UTF-8")); /*한 페이지 결과 수*/
//	        urlBuilder.append("&" + URLEncoder.encode("edi_code","UTF-8") + "=" + URLEncoder.encode("", "UTF-8")); /*보험코드*/
//	        urlBuilder.append("&" + URLEncoder.encode("type","UTF-8") + "=" + URLEncoder.encode("xml", "UTF-8")); /*응답데이터 형식(xml/json) default : xml*/
			
			URL url = new URL(urlBuilder.toString());
			HttpURLConnection conn = (HttpURLConnection) url.openConnection();
			conn.setRequestMethod("GET");
			conn.setRequestProperty("Content-type", "application/xml");
			
			DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
			DocumentBuilder db = dbf.newDocumentBuilder();
			Document doc = db.parse(conn.getInputStream());
			doc.getDocumentElement().normalize();
	
			NodeList nList = doc.getElementsByTagName("item");
			
			if (nList.getLength() <= 0) {
				return list;
			}
			for (int i = 0; i < nList.getLength(); i++) {
				Node node = nList.item(i);
				if (node.getNodeType() == Node.ELEMENT_NODE) {
					Element eElement = (Element) node;
					
					int ITEM_SEQ					= getIntData(eElement, "ITEM_SEQ");
					String ITEM_NAME				= getStrData(eElement, "ITEM_NAME");
					String ENTP_NAME				= getStrData(eElement, "ENTP_NAME");
					String ITEM_IMAGE				= getStrData(eElement, "ITEM_IMAGE");
					String DRUG_SHAPE				= getStrData(eElement, "DRUG_SHAPE");
					String ITEM_PRINT;
					if(getStrData(eElement, "PRINT_FRONT") != null) {
						ITEM_PRINT					= getStrData(eElement, "PRINT_FRONT");
					} else {
						ITEM_PRINT					= getStrData(eElement, "PRINT_BACK");
					}
					String ITEM_COLOR;
					if(getStrData(eElement, "COLOR_CLASS1") != null) {
						ITEM_COLOR					= getStrData(eElement, "COLOR_CLASS1");
					} else {
						ITEM_COLOR					= getStrData(eElement, "COLOR_CLASS2");
					}
					String ITEM_LINE;
					if(getStrData(eElement, "LINE_FRONT") != null) {
						ITEM_LINE					= getStrData(eElement, "LINE_FRONT");
					} else {
						ITEM_LINE					= getStrData(eElement, "LINE_BACK");
					}
					String MARK_IMG;
					if(getStrData(eElement, "MARK_CODE_FRONT_IMG") != null) {
						MARK_IMG					= getStrData(eElement, "MARK_CODE_FRONT_IMG");
					} else {
						MARK_IMG					= getStrData(eElement, "MARK_CODE_BACK_IMG");
					}
	
					Medicine2 info = new Medicine2(ITEM_SEQ, ITEM_NAME, ENTP_NAME, ITEM_IMAGE, DRUG_SHAPE, ITEM_PRINT, ITEM_COLOR, ITEM_LINE, MARK_IMG);
					list.add(info);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		System.out.println("페이지 : " + pageNo++);
//		for(int i = 0; i < list.size(); i++) {
//			System.out.println(list.get(i).toString());
//		}
		System.out.println("사이즈 : "  + list.size());
		
	}
	}

	private static String getStrData(Element eElement, String tagName) {
		try {
			return eElement.getElementsByTagName(tagName).item(0).getTextContent();
		} catch (Exception e) {
			return "-";
		}
	}

	private static int getIntData(Element eElement, String tagName) {
		try {
			return Integer.parseInt(eElement.getElementsByTagName(tagName).item(0).getTextContent());
		} catch (Exception e) {
			return 0;
		}
	}
	
	public static void main(String[] args) {
		searchAll();
	}
}