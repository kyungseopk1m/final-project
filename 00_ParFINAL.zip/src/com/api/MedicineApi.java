package com.api;

import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.vo.Medicine;

public class MedicineApi {
	// 일반검색

	
	public static int pageNo = 1;
	public static List<Medicine> searchAll() {
		List<Medicine> list = new ArrayList<>();
		
		while(true) {
		try {
			StringBuilder urlBuilder = new StringBuilder("http://apis.data.go.kr/1471000/DrbEasyDrugInfoService/getDrbEasyDrugList"); /*URL*/
		        urlBuilder.append("?" + URLEncoder.encode("serviceKey","UTF-8") + "=qox%2BipaXoWnf%2FV01eNjOkt81Eh8nOc%2Fr82zCfdYqtbzqdsVuZr2o1iAq7VI8I0J8L71uxntJKSdmuP91QTQpEQ%3D%3D"); /*Service Key*/
		        urlBuilder.append("&" + "pageNo=" + pageNo); /*페이지번호*/
		        urlBuilder.append("&" + URLEncoder.encode("numOfRows","UTF-8") + "=" + URLEncoder.encode("100", "UTF-8")); /*한 페이지 결과 수*/
//		        urlBuilder.append("&" + URLEncoder.encode("entpName","UTF-8") + "=" + URLEncoder.encode("", "UTF-8")); /*업체명*/
//		        urlBuilder.append("&" + URLEncoder.encode("itemName","UTF-8") + "=" + URLEncoder.encode("", "UTF-8")); /*제품명*/
			
			URL url = new URL(urlBuilder.toString());
			System.out.println(url);
			HttpURLConnection conn = (HttpURLConnection) url.openConnection();
			conn.setRequestMethod("GET");
			conn.setRequestProperty("Content-type", "application/xml");
			
			DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
			DocumentBuilder db = dbf.newDocumentBuilder();
			Document doc = db.parse(conn.getInputStream());
			doc.getDocumentElement().normalize();
			
			NodeList nList = doc.getElementsByTagName("item");
			
			if (nList.getLength() <= 0) {
				return list;
			}
			for (int i = 0; i < nList.getLength(); i++) {
				Node node = nList.item(i);
				if (node.getNodeType() == Node.ELEMENT_NODE) {
					Element eElement = (Element) node;
					
					int itemSeq					= getIntData(eElement, "itemSeq");
					String itemName				= getStrData(eElement, "itemName");
					String entpName				= getStrData(eElement, "entpName");
					String itemImage			= getStrData(eElement, "itemImage");
					String efcyQesitm			= getStrData(eElement, "efcyQesitm");
					String useMethodQesitm		= getStrData(eElement, "useMethodQesitm");
					String depositMethodQesitm	= getStrData(eElement, "depositMethodQesitm");
					String intrcQesitm			= getStrData(eElement, "intrcQesitm");
					String atpnWarnQesitm		= getStrData(eElement, "atpnWarnQesitm");
					String atpnQesitm			= getStrData(eElement, "atpnQesitm");
					String seQesitm				= getStrData(eElement, "seQesitm");
					String openDe				= getStrData(eElement, "openDe");
					String updateDe				= getStrData(eElement, "updateDe");
	
					Medicine info = new Medicine(itemSeq, itemName, entpName, itemImage, efcyQesitm, useMethodQesitm, depositMethodQesitm, intrcQesitm, atpnWarnQesitm, atpnQesitm, seQesitm, openDe, updateDe);
					list.add(info);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		System.out.println("페이지 : " + pageNo++);
//		for(int i = 0; i < list.size(); i++) {
//			System.out.println(list.get(i).toString());
//		}
		System.out.println("사이즈 : " + list.size());
		
		}
	}

	private static String getStrData(Element eElement, String tagName) {
		try {
			return eElement.getElementsByTagName(tagName).item(0).getTextContent();
		} catch (Exception e) {
			return "-";
		}
	}

	private static int getIntData(Element eElement, String tagName) {
		try {
			return Integer.parseInt(eElement.getElementsByTagName(tagName).item(0).getTextContent());
		} catch (Exception e) {
			return 0;
		}
	}
	
//	public static void main(String[] args) {
//		searchAll();
//	}
}