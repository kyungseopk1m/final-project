package com.api;

import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.vo.Health;

public class HealthAPI {
	
	public static void main(String[] args) {
		
		List<Health> hlist = callHealthByXML();
		
		for(Health h : hlist) {
			System.out.println(h.toString());
		}
		System.out.println(hlist.size());
	}
	
//	https://openapi.foodsafetykorea.go.kr/api/c1f3832cb39343f2a10c/I0030/xml/1/10
//	http://openapi.foodsafetykorea.go.kr/api/인증키/서비스명/요청파일타입/요청시작위치/요청종료위치
	public static final String HEALTH_XML_URL = "http://openapi.foodsafetykorea.go.kr/api";
	public static int startIdx = 1; 
	public static int endIdx = 70;
	
	public static List<Health> callHealthByXML() {
		
		List<Health> hlist = new ArrayList<Health>();
		
		while(true) {
			StringBuilder urlBuffer = new StringBuilder(HEALTH_XML_URL);
			urlBuffer.append("/" + "c1f3832cb39343f2a10c"); // 인증키
			urlBuffer.append("/" + "I0030");  // 서비스명
			urlBuffer.append("/" + "xml");    // 요청파일타입
			urlBuffer.append("/" + startIdx); // 요청시작위치
			urlBuffer.append("/" + endIdx);   // 요청종료위치
			// Idx 1~3까지 데이터 6개 / Idx 1~5까지 데이터 15개 / Idx 1~10까지 요청시 55개 
			// 등차수열 합으로 데이터 가져온다!
			
			try {
				URL url = new URL(urlBuffer.toString());
				HttpURLConnection conn = (HttpURLConnection) url.openConnection();
				conn.setRequestMethod("GET");
				
				conn.setRequestProperty("Accept", "application/xml");
				int code = conn.getResponseCode(); // 실제 호출하는부
//				System.out.println("Response code: " + code);

				if (code < 200 || code > 300) {
					System.out.println("페이지가 잘못되었습니다.");
				}
				
				// 3. 페이지 Parsing(해석)
				DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
				DocumentBuilder db = dbf.newDocumentBuilder();

				Document doc = db.parse(conn.getInputStream()); // xml 부를 파싱하여 객체화

				doc.getDocumentElement().normalize();

//				System.out.println("Root Element : " + doc.getDocumentElement().getNodeName());
//				System.out.println("======================================================");

				NodeList nList = doc.getElementsByTagName("row");

				if (nList.getLength() <= 0) {
					return hlist;
				}
				
				for (int i = 0; i < nList.getLength(); i++) {
					Node node = nList.item(i);
//							System.out.println("\nCurrent Element : " + node.getNodeName());
					if (node.getNodeType() == Node.ELEMENT_NODE) {
						try {
							Element eElement = (Element) node;

							String BSSH_NM = getStrData(eElement, "BSSH_NM");
							String PRDLST_NM = getStrData(eElement, "PRDLST_NM");
							String PRDLST_REPORT_NO = getStrData(eElement, "PRDLST_REPORT_NO");
							String PRMS_DT = getStrData(eElement, "PRMS_DT");
							String POG_DAYCNT = getStrData(eElement, "POG_DAYCNT");
							String NTK_MTHD = getStrData(eElement, "NTK_MTHD");
							String PRIMARY_FNCLTY = getStrData(eElement, "PRIMARY_FNCLTY");
							String IFTKN_ATNT_MATR_CN = getStrData(eElement, "IFTKN_ATNT_MATR_CN");
							String CSTDY_MTHD = getStrData(eElement, "CSTDY_MTHD");
							String RAWMTRL_NM = getStrData(eElement, "RAWMTRL_NM");
							String PRDT_SHAP_CD_NM = getStrData(eElement, "PRDT_SHAP_CD_NM");
							String ETC_RAWMTRL_NM = getStrData(eElement, "ETC_RAWMTRL_NM");
							String STDR_STND = getStrData(eElement, "STDR_STND");
									
							Health h = new Health(BSSH_NM, PRDLST_NM, PRDLST_REPORT_NO, PRMS_DT, POG_DAYCNT, 
									NTK_MTHD, PRIMARY_FNCLTY, IFTKN_ATNT_MATR_CN, CSTDY_MTHD, RAWMTRL_NM, 
									PRDT_SHAP_CD_NM, ETC_RAWMTRL_NM, STDR_STND);
							
							hlist.add(h);
						} catch (Exception e) {
							System.out.println("데이터가 잘못되었습니다.");
						}
					}
				}
				System.out.println("데이터 요청 위치 : " + startIdx++);
				
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}
	
	private static String getStrData(Element pElement, String tagName) {
		try {
			return pElement.getElementsByTagName(tagName).item(0).getTextContent().trim();
		} catch (Exception e) {
			return "-";
		}
	}
}
