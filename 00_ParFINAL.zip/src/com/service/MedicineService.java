package com.service;

import static com.common.JDBCTemplate.commit;
import static com.common.JDBCTemplate.getConnection;
import static com.common.JDBCTemplate.rollback;

import java.sql.Connection;

import com.dao.MedicineDao;
import com.vo.Medicine;

public class MedicineService {
	private MedicineDao dao = new MedicineDao();
	private Connection conn = null;
	
	public MedicineService() {
		conn = getConnection();
	}
	
	public int insert(Medicine medicine) {
		int result = dao.insert(conn, medicine);
		if(result > 0) {
			commit(conn);
		} else {
			rollback(conn);
		}
		
//		JDBCTemplate.close(conn); 
		return result;
	}


}
