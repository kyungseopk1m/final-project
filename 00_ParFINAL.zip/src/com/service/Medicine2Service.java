package com.service;

import static com.common.JDBCTemplate.commit;
import static com.common.JDBCTemplate.getConnection;
import static com.common.JDBCTemplate.rollback;

import java.sql.Connection;

import com.dao.Medicine2Dao;
import com.vo.Medicine2;

public class Medicine2Service {
	private Medicine2Dao dao = new Medicine2Dao();
	private Connection conn = null;
	
	public Medicine2Service() {
		conn = getConnection();
	}
	
	public int insert(Medicine2 medicine2) {
		int result = dao.insert(conn, medicine2);
		if(result > 0) {
			commit(conn);
		} else {
			rollback(conn);
		}
		
//		JDBCTemplate.close(conn); 
		return result;
	}


}
