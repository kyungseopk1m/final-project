package com.service;

import static com.common.JDBCTemplate.commit;
import static com.common.JDBCTemplate.getConnection;
import static com.common.JDBCTemplate.rollback;

import java.sql.Connection;

import com.dao.PharmacyDao;
import com.vo.Pharmacy;


public class PharmacyService {
	private PharmacyDao dao = new PharmacyDao();
	private Connection conn = null;
	
	public PharmacyService() {
		conn = getConnection();
	}
	
	public int insert(Pharmacy pharmacy) {
		int result = dao.insert(conn, pharmacy);
		if(result > 0) {
			commit(conn);
		} else {
			rollback(conn);
		}
		
//		JDBCTemplate.close(conn); 
		return result;
	}

}
