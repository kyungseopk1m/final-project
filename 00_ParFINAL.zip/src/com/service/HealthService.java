package com.service;

import java.sql.Connection;

import static com.common.JDBCTemplate.commit;
import static com.common.JDBCTemplate.getConnection;
import static com.common.JDBCTemplate.rollback;

import com.dao.HealthDao;
import com.vo.Health;

public class HealthService {
	private HealthDao dao = new HealthDao();
	private Connection conn = null;
	
	public HealthService() {
		conn = getConnection();
	}
	
	public int insert(Health health) {
		int result = dao.insert(conn, health);
		if(result > 0) {
			commit(conn);
		} else {
			rollback(conn);
		}
		
//		JDBCTemplate.close(conn); 
		return result;
	}

}
