package com.controller;

import java.util.List;

import com.api.PharmacyAPI;
import com.service.PharmacyService;
import com.vo.Pharmacy;

public class PharmacyController {
	private PharmacyService PharmacyService = new PharmacyService();
	
	public static void main(String[] args) {
		PharmacyController pc = new PharmacyController();
		pc.initPharmacy();
	}
	
	public void initPharmacy() {
		
		List<Pharmacy> list = PharmacyAPI.callPharmacyByXML();
		
		while (true) {
			
			if (list == null || list.isEmpty()) {
				break;
			}
			
			for (Pharmacy p : list) {
				System.out.println(p);
				PharmacyService.insert(p);
			}
			list = null;
		}
	}

}
