package com.controller;

import java.util.List;

import com.api.HealthAPI;
import com.service.HealthService;
import com.vo.Health;

public class HealthController {
	private HealthService HealthService = new HealthService();
	
	public static void main(String[] args) {
		HealthController hc = new HealthController();
		hc.initHealth();
	}
	
	public void initHealth() {
		
		List<Health> list = HealthAPI.callHealthByXML();
		
		while (true) {
			
			if (list == null || list.isEmpty()) {
				break;
			}
			
			for (Health h : list) {
				System.out.println(h);
				HealthService.insert(h);
			}
			list = null;
		}
	}
}
