package com.controller;

import java.util.List;

import com.api.MedicineApi;
import com.service.MedicineService;
import com.vo.Medicine;

public class MedicineController {
private MedicineService MedicineService = new MedicineService();
	
	public static void main(String[] args) {
		MedicineController mc = new MedicineController();
		mc.initMedicine();
	}
	
	public void initMedicine() {
		
		List<Medicine> list = MedicineApi.searchAll();
		
		while (true) {
			
			if (list == null || list.isEmpty()) {
				break;
			}
			
			for (Medicine m : list) {
				System.out.println(m);
				MedicineService.insert(m);
			}
			list = null;
		}
	}

}
