package com.controller;

import java.util.List;

import com.api.MedicineApi2;
import com.service.Medicine2Service;
import com.vo.Medicine2;


public class Medicine2Controller {
private Medicine2Service Medicine2Service = new Medicine2Service();
	
	public static void main(String[] args) {
		Medicine2Controller m2c = new Medicine2Controller();
		m2c.initMedicine2();
	}
	
	public void initMedicine2() {
		
		List<Medicine2> list = MedicineApi2.searchAll();
		
		while (true) {
			
			if (list == null || list.isEmpty()) {
				break;
			}
			
			for (Medicine2 m : list) {
				System.out.println(m);
				Medicine2Service.insert(m);
			}
			list = null;
		}
	}
}
