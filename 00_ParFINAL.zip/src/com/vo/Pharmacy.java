package com.vo;

public class Pharmacy {
	
	private String dutyUrl	 ; // 기관주소
	private String dutyAddr  ; // 주소
	private String dutyInf   ; // 기관설명상세(비고)
	private String dutyMapimg; // 간이약도
	private String dutyName  ; // 기관명
	private String dutyTel1  ; // 대표전화1
	private String dutyTime1c; // 진료시간(월요일)C	(1~7 : 월~일, 8 : 공휴일)
	private String dutyTime6c; // 진료시간(토요일)C	(c : 영업종료, s : 영업시작)
	private String dutyTime7c; // 진료시간(일요일)C	
	private String dutyTime8c; // 진료시간(공휴일)C	
	private String dutyTime1s; // 진료시간(월요일)S	
	private String dutyTime6s; // 진료시간(토요일)S	
	private String dutyTime7s; // 진료시간(일요일)S	
	private String dutyTime8s; // 진료시간(공휴일)S	
	private String postCdn1  ; // 우편번호1	
	private String postCdn2  ; // 우편번호2	
	private String wgs84Lon  ; // 약국경도	
	private String wgs84Lat  ; // 약국위도
	
	public Pharmacy() {
		super();
	}

	public Pharmacy(String dutyUrl, String dutyAddr, String dutyInf, String dutyMapimg, String dutyName,
			String dutyTel1, String dutyTime1c, String dutyTime6c, String dutyTime7c, String dutyTime8c,
			String dutyTime1s, String dutyTime6s, String dutyTime7s, String dutyTime8s, String postCdn1,
			String postCdn2, String wgs84Lon, String wgs84Lat) {
		super();
		this.dutyUrl = dutyUrl;
		this.dutyAddr = dutyAddr;
		this.dutyInf = dutyInf;
		this.dutyMapimg = dutyMapimg;
		this.dutyName = dutyName;
		this.dutyTel1 = dutyTel1;
		this.dutyTime1c = dutyTime1c;
		this.dutyTime6c = dutyTime6c;
		this.dutyTime7c = dutyTime7c;
		this.dutyTime8c = dutyTime8c;
		this.dutyTime1s = dutyTime1s;
		this.dutyTime6s = dutyTime6s;
		this.dutyTime7s = dutyTime7s;
		this.dutyTime8s = dutyTime8s;
		this.postCdn1 = postCdn1;
		this.postCdn2 = postCdn2;
		this.wgs84Lon = wgs84Lon;
		this.wgs84Lat = wgs84Lat;
	}

	@Override
	public String toString() {
		return "Pharmacy [dutyUrl=" + dutyUrl + ", dutyAddr=" + dutyAddr + ", dutyInf=" + dutyInf + ", dutyMapimg="
				+ dutyMapimg + ", dutyName=" + dutyName + ", dutyTel1=" + dutyTel1 + ", dutyTime1c=" + dutyTime1c
				+ ", dutyTime6c=" + dutyTime6c + ", dutyTime7c=" + dutyTime7c + ", dutyTime8c=" + dutyTime8c
				+ ", dutyTime1s=" + dutyTime1s + ", dutyTime6s=" + dutyTime6s + ", dutyTime7s=" + dutyTime7s
				+ ", dutyTime8s=" + dutyTime8s + ", postCdn1=" + postCdn1 + ", postCdn2=" + postCdn2 + ", wgs84Lon="
				+ wgs84Lon + ", wgs84Lat=" + wgs84Lat + "]";
	}

	public String getDutyUrl() {
		return dutyUrl;
	}

	public void setDutyUrl(String dutyUrl) {
		this.dutyUrl = dutyUrl;
	}

	public String getDutyAddr() {
		return dutyAddr;
	}

	public void setDutyAddr(String dutyAddr) {
		this.dutyAddr = dutyAddr;
	}

	public String getDutyInf() {
		return dutyInf;
	}

	public void setDutyInf(String dutyInf) {
		this.dutyInf = dutyInf;
	}

	public String getDutyMapimg() {
		return dutyMapimg;
	}

	public void setDutyMapimg(String dutyMapimg) {
		this.dutyMapimg = dutyMapimg;
	}

	public String getDutyName() {
		return dutyName;
	}

	public void setDutyName(String dutyName) {
		this.dutyName = dutyName;
	}

	public String getDutyTel1() {
		return dutyTel1;
	}

	public void setDutyTel1(String dutyTel1) {
		this.dutyTel1 = dutyTel1;
	}

	public String getDutyTime1c() {
		return dutyTime1c;
	}

	public void setDutyTime1c(String dutyTime1c) {
		this.dutyTime1c = dutyTime1c;
	}

	public String getDutyTime6c() {
		return dutyTime6c;
	}

	public void setDutyTime6c(String dutyTime6c) {
		this.dutyTime6c = dutyTime6c;
	}

	public String getDutyTime7c() {
		return dutyTime7c;
	}

	public void setDutyTime7c(String dutyTime7c) {
		this.dutyTime7c = dutyTime7c;
	}

	public String getDutyTime8c() {
		return dutyTime8c;
	}

	public void setDutyTime8c(String dutyTime8c) {
		this.dutyTime8c = dutyTime8c;
	}

	public String getDutyTime1s() {
		return dutyTime1s;
	}

	public void setDutyTime1s(String dutyTime1s) {
		this.dutyTime1s = dutyTime1s;
	}

	public String getDutyTime6s() {
		return dutyTime6s;
	}

	public void setDutyTime6s(String dutyTime6s) {
		this.dutyTime6s = dutyTime6s;
	}

	public String getDutyTime7s() {
		return dutyTime7s;
	}

	public void setDutyTime7s(String dutyTime7s) {
		this.dutyTime7s = dutyTime7s;
	}

	public String getDutyTime8s() {
		return dutyTime8s;
	}

	public void setDutyTime8s(String dutyTime8s) {
		this.dutyTime8s = dutyTime8s;
	}

	public String getPostCdn1() {
		return postCdn1;
	}

	public void setPostCdn1(String postCdn1) {
		this.postCdn1 = postCdn1;
	}

	public String getPostCdn2() {
		return postCdn2;
	}

	public void setPostCdn2(String postCdn2) {
		this.postCdn2 = postCdn2;
	}

	public String getWgs84Lon() {
		return wgs84Lon;
	}

	public void setWgs84Lon(String wgs84Lon) {
		this.wgs84Lon = wgs84Lon;
	}

	public String getWgs84Lat() {
		return wgs84Lat;
	}

	public void setWgs84Lat(String wgs84Lat) {
		this.wgs84Lat = wgs84Lat;
	}
	
}