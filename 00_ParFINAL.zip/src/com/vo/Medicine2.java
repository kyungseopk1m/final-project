package com.vo;

public class Medicine2 {
	private int ITEM_SEQ;			// 품목코드
	private String ITEM_NAME;		// 제품명
	private String ENTP_NAME;		// 제조사
	private String ITEM_IMAGE;		// 이미지
	private String DRUG_SHAPE;		// 모양
	private String ITEM_PRINT;		// 표시
	private String ITEM_COLOR;		// 색상
	private String ITEM_LINE;		// 분할선
	private String MARK_IMG;		// 마크이미지
	
	public Medicine2() {}

	public Medicine2(int iTEM_SEQ, String iTEM_NAME, String eNTP_NAME, String iTEM_IMAGE, String dRUG_SHAPE,
			String iTEM_PRINT, String iTEM_COLOR, String iTEM_LINE, String mARK_IMG) {
		super();
		ITEM_SEQ = iTEM_SEQ;
		ITEM_NAME = iTEM_NAME;
		ENTP_NAME = eNTP_NAME;
		ITEM_IMAGE = iTEM_IMAGE;
		DRUG_SHAPE = dRUG_SHAPE;
		ITEM_PRINT = iTEM_PRINT;
		ITEM_COLOR = iTEM_COLOR;
		ITEM_LINE = iTEM_LINE;
		MARK_IMG = mARK_IMG;
	}

	public int getITEM_SEQ() {
		return ITEM_SEQ;
	}

	public void setITEM_SEQ(int iTEM_SEQ) {
		ITEM_SEQ = iTEM_SEQ;
	}

	public String getITEM_NAME() {
		return ITEM_NAME;
	}

	public void setITEM_NAME(String iTEM_NAME) {
		ITEM_NAME = iTEM_NAME;
	}

	public String getENTP_NAME() {
		return ENTP_NAME;
	}

	public void setENTP_NAME(String eNTP_NAME) {
		ENTP_NAME = eNTP_NAME;
	}

	public String getITEM_IMAGE() {
		return ITEM_IMAGE;
	}

	public void setITEM_IMAGE(String iTEM_IMAGE) {
		ITEM_IMAGE = iTEM_IMAGE;
	}

	public String getDRUG_SHAPE() {
		return DRUG_SHAPE;
	}

	public void setDRUG_SHAPE(String dRUG_SHAPE) {
		DRUG_SHAPE = dRUG_SHAPE;
	}

	public String getITEM_PRINT() {
		return ITEM_PRINT;
	}

	public void setITEM_PRINT(String iTEM_PRINT) {
		ITEM_PRINT = iTEM_PRINT;
	}

	public String getITEM_COLOR() {
		return ITEM_COLOR;
	}

	public void setITEM_COLOR(String iTEM_COLOR) {
		ITEM_COLOR = iTEM_COLOR;
	}

	public String getITEM_LINE() {
		return ITEM_LINE;
	}

	public void setITEM_LINE(String iTEM_LINE) {
		ITEM_LINE = iTEM_LINE;
	}

	public String getMARK_IMG() {
		return MARK_IMG;
	}

	public void setMARK_IMG(String mARK_IMG) {
		MARK_IMG = mARK_IMG;
	}

	@Override
	public String toString() {
		return "Medicine2 [ITEM_SEQ=" + ITEM_SEQ + ", ITEM_NAME=" + ITEM_NAME + ", ENTP_NAME=" + ENTP_NAME
				+ ", ITEM_IMAGE=" + ITEM_IMAGE + ", DRUG_SHAPE=" + DRUG_SHAPE + ", ITEM_PRINT=" + ITEM_PRINT
				+ ", ITEM_COLOR=" + ITEM_COLOR + ", ITEM_LINE=" + ITEM_LINE + ", MARK_IMG=" + MARK_IMG + "]";
	}
	
}
