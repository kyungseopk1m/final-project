package com.vo;

public class Health {
	
	private String BSSH_NM;  	 	   // 업체명
	private String PRDLST_NM;	 	   // 제품명	
	private String PRDLST_REPORT_NO;   // 품목제조번호
	private String PRMS_DT;		 	   // 허가일자
	private String POG_DAYCNT;	 	   // 유통/소비기한
	private String NTK_MTHD;	 	   // 섭취방법
	private String PRIMARY_FNCLTY;	   // 주된기능성
	private String IFTKN_ATNT_MATR_CN; // 섭취시주의사항
	private String CSTDY_MTHD;	       // 보관방법
	private String RAWMTRL_NM;	       // 제품유형 
	private String PRDT_SHAP_CD_NM;	   // 제품형태 (ex 캡슐 분말)
	private String ETC_RAWMTRL_NM;	   // 기타 원재료
	private String STDR_STND;	       // 성분 분석
	
	public Health() {
		super();
	}

	public Health(String bSSH_NM, String pRDLST_NM, String pRDLST_REPORT_NO, String pRMS_DT, String pOG_DAYCNT,
			String nTK_MTHD, String pRIMARY_FNCLTY, String iFTKN_ATNT_MATR_CN, String cSTDY_MTHD, String rAWMTRL_NM,
			String pRDT_SHAP_CD_NM, String eTC_RAWMTRL_NM, String sTDR_STND) {
		super();
		BSSH_NM = bSSH_NM;
		PRDLST_NM = pRDLST_NM;
		PRDLST_REPORT_NO = pRDLST_REPORT_NO;
		PRMS_DT = pRMS_DT;
		POG_DAYCNT = pOG_DAYCNT;
		NTK_MTHD = nTK_MTHD;
		PRIMARY_FNCLTY = pRIMARY_FNCLTY;
		IFTKN_ATNT_MATR_CN = iFTKN_ATNT_MATR_CN;
		CSTDY_MTHD = cSTDY_MTHD;
		RAWMTRL_NM = rAWMTRL_NM;
		PRDT_SHAP_CD_NM = pRDT_SHAP_CD_NM;
		ETC_RAWMTRL_NM = eTC_RAWMTRL_NM;
		STDR_STND = sTDR_STND;
	}

	@Override
	public String toString() {
		return "Health [BSSH_NM=" + BSSH_NM + ", PRDLST_NM=" + PRDLST_NM + ", PRDLST_REPORT_NO=" + PRDLST_REPORT_NO
				+ ", PRMS_DT=" + PRMS_DT + ", POG_DAYCNT=" + POG_DAYCNT + ", NTK_MTHD=" + NTK_MTHD + ", PRIMARY_FNCLTY="
				+ PRIMARY_FNCLTY + ", IFTKN_ATNT_MATR_CN=" + IFTKN_ATNT_MATR_CN + ", CSTDY_MTHD=" + CSTDY_MTHD
				+ ", RAWMTRL_NM=" + RAWMTRL_NM + ", PRDT_SHAP_CD_NM=" + PRDT_SHAP_CD_NM + ", ETC_RAWMTRL_NM="
				+ ETC_RAWMTRL_NM + ", STDR_STND=" + STDR_STND + "]";
	}

	public String getBSSH_NM() {
		return BSSH_NM;
	}

	public void setBSSH_NM(String bSSH_NM) {
		BSSH_NM = bSSH_NM;
	}

	public String getPRDLST_NM() {
		return PRDLST_NM;
	}

	public void setPRDLST_NM(String pRDLST_NM) {
		PRDLST_NM = pRDLST_NM;
	}

	public String getPRDLST_REPORT_NO() {
		return PRDLST_REPORT_NO;
	}

	public void setPRDLST_REPORT_NO(String pRDLST_REPORT_NO) {
		PRDLST_REPORT_NO = pRDLST_REPORT_NO;
	}

	public String getPRMS_DT() {
		return PRMS_DT;
	}

	public void setPRMS_DT(String pRMS_DT) {
		PRMS_DT = pRMS_DT;
	}

	public String getPOG_DAYCNT() {
		return POG_DAYCNT;
	}

	public void setPOG_DAYCNT(String pOG_DAYCNT) {
		POG_DAYCNT = pOG_DAYCNT;
	}

	public String getNTK_MTHD() {
		return NTK_MTHD;
	}

	public void setNTK_MTHD(String nTK_MTHD) {
		NTK_MTHD = nTK_MTHD;
	}

	public String getPRIMARY_FNCLTY() {
		return PRIMARY_FNCLTY;
	}

	public void setPRIMARY_FNCLTY(String pRIMARY_FNCLTY) {
		PRIMARY_FNCLTY = pRIMARY_FNCLTY;
	}

	public String getIFTKN_ATNT_MATR_CN() {
		return IFTKN_ATNT_MATR_CN;
	}

	public void setIFTKN_ATNT_MATR_CN(String iFTKN_ATNT_MATR_CN) {
		IFTKN_ATNT_MATR_CN = iFTKN_ATNT_MATR_CN;
	}

	public String getCSTDY_MTHD() {
		return CSTDY_MTHD;
	}

	public void setCSTDY_MTHD(String cSTDY_MTHD) {
		CSTDY_MTHD = cSTDY_MTHD;
	}

	public String getRAWMTRL_NM() {
		return RAWMTRL_NM;
	}

	public void setRAWMTRL_NM(String rAWMTRL_NM) {
		RAWMTRL_NM = rAWMTRL_NM;
	}

	public String getPRDT_SHAP_CD_NM() {
		return PRDT_SHAP_CD_NM;
	}

	public void setPRDT_SHAP_CD_NM(String pRDT_SHAP_CD_NM) {
		PRDT_SHAP_CD_NM = pRDT_SHAP_CD_NM;
	}

	public String getETC_RAWMTRL_NM() {
		return ETC_RAWMTRL_NM;
	}

	public void setETC_RAWMTRL_NM(String eTC_RAWMTRL_NM) {
		ETC_RAWMTRL_NM = eTC_RAWMTRL_NM;
	}

	public String getSTDR_STND() {
		return STDR_STND;
	}

	public void setSTDR_STND(String sTDR_STND) {
		STDR_STND = sTDR_STND;
	}
	
}
