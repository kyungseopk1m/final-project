package com.vo;

public class Medicine {
	private int itemSeq;				// 품목기준코드
	private String itemName;			// 제품명
	private String entpName;			// 제조사
	private String itemImage;			// 이미지
	private String efcyQesitm;			// 증상
	private String useMethodQesitm;		// 섭취방법
	private String depositMethodQesitm;	// 보관법
	private String intrcQesitm;			// 상호작용
	private String atpnWarnQesitm;		// 경고
	private String atpnQesitm;			// 주의사항
	private String seQesitm;			// 부작용
	private String openDe;				// 공개일자
	private String updateDe;			// 수정일자
	
	public Medicine() {}

	public Medicine(int itemSeq, String itemName, String entpName, String itemImage, String efcyQesitm,
			String useMethodQesitm, String depositMethodQesitm, String intrcQesitm, String atpnWarnQesitm,
			String atpnQesitm, String seQesitm, String openDe, String updateDe) {
		super();
		this.itemSeq = itemSeq;
		this.itemName = itemName;
		this.entpName = entpName;
		this.itemImage = itemImage;
		this.efcyQesitm = efcyQesitm;
		this.useMethodQesitm = useMethodQesitm;
		this.depositMethodQesitm = depositMethodQesitm;
		this.intrcQesitm = intrcQesitm;
		this.atpnWarnQesitm = atpnWarnQesitm;
		this.atpnQesitm = atpnQesitm;
		this.seQesitm = seQesitm;
		this.openDe = openDe;
		this.updateDe = updateDe;
	}

	public Medicine(int itemSeq, String itemName, String entpName, String itemImage) {
		super();
		this.itemSeq = itemSeq;
		this.itemName = itemName;
		this.entpName = entpName;
		this.itemImage = itemImage;
	}

	public int getItemSeq() {
		return itemSeq;
	}

	public void setItemSeq(int itemSeq) {
		this.itemSeq = itemSeq;
	}

	public String getItemName() {
		return itemName;
	}

	public void setItemName(String itemName) {
		this.itemName = itemName;
	}

	public String getEntpName() {
		return entpName;
	}

	public void setEntpName(String entpName) {
		this.entpName = entpName;
	}

	public String getItemImage() {
		return itemImage;
	}

	public void setItemImage(String itemImage) {
		this.itemImage = itemImage;
	}

	public String getEfcyQesitm() {
		return efcyQesitm;
	}

	public void setEfcyQesitm(String efcyQesitm) {
		this.efcyQesitm = efcyQesitm;
	}

	public String getUseMethodQesitm() {
		return useMethodQesitm;
	}

	public void setUseMethodQesitm(String useMethodQesitm) {
		this.useMethodQesitm = useMethodQesitm;
	}

	public String getDepositMethodQesitm() {
		return depositMethodQesitm;
	}

	public void setDepositMethodQesitm(String depositMethodQesitm) {
		this.depositMethodQesitm = depositMethodQesitm;
	}

	public String getIntrcQesitm() {
		return intrcQesitm;
	}

	public void setIntrcQesitm(String intrcQesitm) {
		this.intrcQesitm = intrcQesitm;
	}

	public String getAtpnWarnQesitm() {
		return atpnWarnQesitm;
	}

	public void setAtpnWarnQesitm(String atpnWarnQesitm) {
		this.atpnWarnQesitm = atpnWarnQesitm;
	}

	public String getAtpnQesitm() {
		return atpnQesitm;
	}

	public void setAtpnQesitm(String atpnQesitm) {
		this.atpnQesitm = atpnQesitm;
	}

	public String getSeQesitm() {
		return seQesitm;
	}

	public void setSeQesitm(String seQesitm) {
		this.seQesitm = seQesitm;
	}

	public String getOpenDe() {
		return openDe;
	}

	public void setOpenDe(String openDe) {
		this.openDe = openDe;
	}

	public String getUpdateDe() {
		return updateDe;
	}

	public void setUpdateDe(String updateDe) {
		this.updateDe = updateDe;
	}

	@Override
	public String toString() {
		return "Medicine [itemSeq=" + itemSeq + ", itemName=" + itemName + ", entpName=" + entpName + ", itemImage="
				+ itemImage + ", efcyQesitm=" + efcyQesitm + ", useMethodQesitm=" + useMethodQesitm
				+ ", depositMethodQesitm=" + depositMethodQesitm + ", intrcQesitm=" + intrcQesitm + ", atpnWarnQesitm="
				+ atpnWarnQesitm + ", atpnQesitm=" + atpnQesitm + ", seQesitm=" + seQesitm + ", openDe=" + openDe
				+ ", updateDe=" + updateDe + "]";
	}
	
}
