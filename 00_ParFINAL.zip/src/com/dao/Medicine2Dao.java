package com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;

import com.vo.Medicine2;


public class Medicine2Dao {
	public int insert(Connection conn, Medicine2 medicine2) {
		try {
			String sql = "INSERT INTO Medicine2(ITEM_SEQ, ITEM_NAME, ENTP_NAME, ITEM_IMAGE, "
					+ "DRUG_SHAPE, ITEM_PRINT, ITEM_COLOR, ITEM_LINE, MARK_IMG) "
					+ "VALUES(?,?,?,?,?,?,?,?,?)";
			
			PreparedStatement pstmt = conn.prepareStatement(sql);
			
			int cnt = 1;
			pstmt.setInt(cnt++, medicine2.getITEM_SEQ());
			pstmt.setString(cnt++, medicine2.getITEM_NAME());
			pstmt.setString(cnt++, medicine2.getENTP_NAME());
			pstmt.setString(cnt++, medicine2.getITEM_IMAGE());
			pstmt.setString(cnt++, medicine2.getDRUG_SHAPE());
			pstmt.setString(cnt++, medicine2.getITEM_PRINT());
			pstmt.setString(cnt++, medicine2.getITEM_COLOR());
			pstmt.setString(cnt++, medicine2.getITEM_LINE());
			pstmt.setString(cnt++, medicine2.getMARK_IMG());
			
			int result = pstmt.executeUpdate();
			pstmt.close();
			return result;
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return -1;
	}


}
