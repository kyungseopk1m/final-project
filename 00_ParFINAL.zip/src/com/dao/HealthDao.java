package com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;

import com.vo.Health;

public class HealthDao {
	public int insert(Connection conn, Health health) {
		try {
			String sql = "INSERT INTO HEALTH(PRDLST_REPORT_NO, BSSH_NM, PRDLST_NM, PRMS_DT, POG_DAYCNT, NTK_MTHD, "
					+ "PRIMARY_FNCLTY, IFTKN_ATNT_MATR_CN, CSTDY_MTHD, RAWMTRL_NM, PRDT_SHAP_CD_NM, ETC_RAWMTRL_NM, STDR_STND) "
					+ "VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)";
						
	
			PreparedStatement pstmt = conn.prepareStatement(sql);
			
			int cnt = 1;
			pstmt.setString(cnt++, health.getPRDLST_REPORT_NO());
			pstmt.setString(cnt++, health.getBSSH_NM());
			pstmt.setString(cnt++, health.getPRDLST_NM());
			pstmt.setString(cnt++, health.getPRMS_DT());
			pstmt.setString(cnt++, health.getPOG_DAYCNT());
			pstmt.setString(cnt++, health.getNTK_MTHD());
			pstmt.setString(cnt++, health.getPRIMARY_FNCLTY());
			pstmt.setString(cnt++, health.getIFTKN_ATNT_MATR_CN());
			pstmt.setString(cnt++, health.getCSTDY_MTHD());
			pstmt.setString(cnt++, health.getRAWMTRL_NM());
			pstmt.setString(cnt++, health.getPRDT_SHAP_CD_NM());
			pstmt.setString(cnt++, health.getETC_RAWMTRL_NM());
			pstmt.setString(cnt++, health.getSTDR_STND());
			
			int result = pstmt.executeUpdate();
			pstmt.close();
			return result;
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return -1;
	}

}