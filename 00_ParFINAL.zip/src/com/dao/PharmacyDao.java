package com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;

import com.vo.Pharmacy;

public class PharmacyDao {
	public int insert(Connection conn, Pharmacy pharmacy) {
		try {
			String sql = "INSERT INTO Pharmacy(dutyNo, dutyUrl, dutyAddr, "
					+ "dutyInf, dutyMapimg, dutyName, dutyTel1, "
					+ "dutyTime1c, dutyTime6c, dutyTime7c, dutyTime8c, "
					+ "dutyTime1s, dutyTime6s, dutyTime7s, dutyTime8s, postCdn1, "
					+ "postCdn2, wgs84Lon, wgs84Lat) "
					+ "VALUES(SEQ_dutyNo.nextval,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
			
			PreparedStatement pstmt = conn.prepareStatement(sql);
			
			int cnt = 1;
			pstmt.setString(cnt++, pharmacy.getDutyUrl());
			pstmt.setString(cnt++, pharmacy.getDutyAddr());
			pstmt.setString(cnt++, pharmacy.getDutyInf());
			pstmt.setString(cnt++, pharmacy.getDutyMapimg());
			pstmt.setString(cnt++, pharmacy.getDutyName());
			pstmt.setString(cnt++, pharmacy.getDutyTel1());
			pstmt.setString(cnt++, pharmacy.getDutyTime1c());
			pstmt.setString(cnt++, pharmacy.getDutyTime6c());
			pstmt.setString(cnt++, pharmacy.getDutyTime7c());
			pstmt.setString(cnt++, pharmacy.getDutyTime8c());
			pstmt.setString(cnt++, pharmacy.getDutyTime1s());
			pstmt.setString(cnt++, pharmacy.getDutyTime6s());
			pstmt.setString(cnt++, pharmacy.getDutyTime7s());
			pstmt.setString(cnt++, pharmacy.getDutyTime8s());
			pstmt.setString(cnt++, pharmacy.getPostCdn1());
			pstmt.setString(cnt++, pharmacy.getPostCdn2());
			pstmt.setString(cnt++, pharmacy.getWgs84Lon());
			pstmt.setString(cnt++, pharmacy.getWgs84Lat());
			
			int result = pstmt.executeUpdate();
			pstmt.close();
			return result;
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return -1;
	}

}
