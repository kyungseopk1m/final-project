package com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;

import com.vo.Medicine;


public class MedicineDao {
	public int insert(Connection conn, Medicine medicine) {
		try {
			String sql = "INSERT INTO MEDICINE(itemSeq,itemName, entpName, itemImage, efcyQesitm, useMethodQesitm, "
					+ "depositMethodQesitm, intrcQesitm, atpnWarnQesitm, atpnQesitm, seQesitm, "
					+ "openDe, updateDe) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)";
			
			PreparedStatement pstmt = conn.prepareStatement(sql);
			
			int cnt = 1;
			pstmt.setInt(cnt++, medicine.getItemSeq());
			pstmt.setString(cnt++, medicine.getItemName());
			pstmt.setString(cnt++, medicine.getEntpName());
			pstmt.setString(cnt++, medicine.getItemImage());
			pstmt.setString(cnt++, medicine.getEfcyQesitm());
			pstmt.setString(cnt++, medicine.getUseMethodQesitm());
			pstmt.setString(cnt++, medicine.getDepositMethodQesitm());
			pstmt.setString(cnt++, medicine.getIntrcQesitm());
			pstmt.setString(cnt++, medicine.getAtpnWarnQesitm());
			pstmt.setString(cnt++, medicine.getAtpnQesitm());
			pstmt.setString(cnt++, medicine.getSeQesitm());
			pstmt.setString(cnt++, medicine.getOpenDe());
			pstmt.setString(cnt++, medicine.getUpdateDe());
			
			
			int result = pstmt.executeUpdate();
			pstmt.close();
			return result;
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return -1;
	}

}